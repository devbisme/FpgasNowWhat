/*
 * Copyright (c) 2009 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

/*
 * helloworld.c: simple test application
 */

#include <stdio.h>
#include "platform.h"

#include "xparameters.h"
#include "xgpio.h"


/************************** Constant Definitions *****************************/

#define LED 0x01   /* Assumes bit 0 of GPIO is connected to an LED  */

/*
 * The following constant maps to the name of the hardware instances that
 * were created in the EDK XPS system.
 */
#define GPIO_EXAMPLE_DEVICE_ID  XPAR_LEDS_DEVICE_ID

/*
 * The following constant is used to wait after an LED is turned on to make
 * sure that it is visible to the human eye.  This constant might need to be
 * tuned for faster or slower processor speeds.
 */
#define LED_DELAY     1000000

/*
 * The following constant is used to determine which channel of the GPIO is
 * used for the LED if there are 2 channels supported.
 */
#define LED_CHANNEL 1

/************************** Variable Definitions *****************************/

/*
 * The following are declared globally so they are zeroed and so they are
 * easily accessible from a debugger
 */

XGpio Gpio; /* The Instance of the GPIO Driver */

/*****************************************************************************/
/**
*
* The purpose of this function is to illustrate how to use the GPIO level 1
* driver to turn on and off an LED.
*
* @param        None
*
* @return       XST_FAILURE to indicate that the GPIO Intialisation had failed.
*
* @note         This function will not return if the test is running.
*
******************************************************************************/
int main(void)
{
        u32 Data;
        int Status;
        volatile int Delay;

        /*
         * Initialize the GPIO driver
         */
        Status = XGpio_Initialize(&Gpio, GPIO_EXAMPLE_DEVICE_ID);
        if (Status != XST_SUCCESS) {
                return XST_FAILURE;
        }

        /*
         * Set the direction for all signals to be inputs except the
         * LED output
         */
        XGpio_SetDataDirection(&Gpio, LED_CHANNEL, ~LED);

        /* Loop forever blinking the LED */
        while (1) {

    			/* Turn off the LED by clearing the bit. */
                XGpio_DiscreteClear(&Gpio, LED_CHANNEL, LED);

                /* Wait a small amount of time so the LED is visible */
                for (Delay = 0; Delay < LED_DELAY; Delay++);

        		/* Turn on the LED by setting the bit. */
                XGpio_DiscreteSet(&Gpio, LED_CHANNEL, LED);

                /* Wait a small amount of time so the LED is visible */
                for (Delay = 0; Delay < LED_DELAY; Delay++);
        }

        return XST_SUCCESS;
}


